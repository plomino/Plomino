## START document_title {
doc = plominoContext
min = doc.getItem("min")
max = doc.getItem("max")
return "Validate number between {min} and {max}".format(min=min, max=max)
## END document_title }
