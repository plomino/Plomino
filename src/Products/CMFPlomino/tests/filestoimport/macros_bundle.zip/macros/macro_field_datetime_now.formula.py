## START formula {
code = "return Now()"
return code
## END formula }
