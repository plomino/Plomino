## START formula {
doc = plominoContext
field_name_ = doc.getItem('field_name', '')
field_compare_ = doc.getItem('field_compare', '')
field_value_ = doc.getItem('field_value', '')
code = """
field_name = \"\"\"{field_name}\"\"\"
field_value = \"\"\"{field_value}\"\"\"
if not plominoContext.hasItem(field_name):
    return False
field_result = plominoContext.getItem(field_name)
if field_name != 'Form':
    form = plominoContext.getForm()
    field = getattr(form, field_name)
    if field.field_mode in ["COMPUTED","COMPUTEDONSAVE"]:
        field_result = form.computeFieldValue(field_name, plominoContext)
    elif field.field_type == 'ATTACHMENT':
        field_result = getattr(plominoContext.REQUEST.get(field_name),'filename','')
result = field_value {field_compare} str(field_result)
return result
    """.format(
        field_name=field_name_,
        field_compare=field_compare_,
        field_value=field_value_
    )
return code
## END formula }
