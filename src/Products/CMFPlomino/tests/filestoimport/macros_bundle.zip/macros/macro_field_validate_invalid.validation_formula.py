## START formula {
doc = plominoContext
invalid_message_ = doc.getItem('invalid_message')
code = """
return '''{invalid_message}'''
""".format(invalid_message=invalid_message_)
return code
## END formula }
