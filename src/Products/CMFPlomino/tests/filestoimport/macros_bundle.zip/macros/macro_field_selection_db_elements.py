## START document_title {
type_ = plominoDocument.getItem('element_type')
return 'Select from {type}'.format(type=type_)
## END document_title }
