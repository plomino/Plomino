## START formula {
return '%Y-%m-%d'
## END formula }
