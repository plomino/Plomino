## START formula {
return """return 'autofocus'"""
## END formula }
