## START formula {
return 'none'
## END formula }
