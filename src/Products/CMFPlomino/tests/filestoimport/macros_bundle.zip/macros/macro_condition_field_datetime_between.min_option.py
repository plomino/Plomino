## START formula {
return 'pick'
## END formula }
