## START formula {
formId = plominoDocument.getItem("formlist", "")
code = """
return '%s' 
""" % formId
return code
## END formula }
