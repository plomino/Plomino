## START document_title {
doc = plominoContext
invalid_message_ = doc.getItem('invalid_message')
code = """Show invalid message - {invalid_message}""".format(invalid_message=invalid_message_)
return code
## END document_title }
