## START formula {
return 'chars'
## END formula }
