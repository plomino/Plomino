## START formula {
code = """
return True
"""
return code
## END formula }
